# Penerbitan KITABUDDY 2.0 di Vercel (Preview dahulu)

## Penting
Konfigurasi ini menerbitkan frontend Vite sebagai laman preview. Ia TIDAK menerbitkan API Express dalam `server/index.mjs`. API itu menggunakan `app.listen()` dan perlu dihoskan/diadaptasi secara berasingan sebelum laporan SAFE, muat naik bukti, semakan status atau dashboard staf boleh digunakan dalam talian. Jangan gunakan laporan murid sebenar sehingga backend, Firebase Rules, Turnstile dan akses staf diuji.

## Cara menerbitkan frontend preview
1. Muat naik kandungan folder projek ini ke repositori GitHub persendirian. Jangan masukkan `.env`, `server/.env`, service-account JSON, token atau rahsia.
2. Buka https://vercel.com/new dan import repositori tersebut.
3. Pilih Framework Preset `Vite`, Root Directory `./` (folder yang mengandungi `package.json`), Build Command `npm run build`, dan Output Directory `dist`.
4. Jika Vercel meminta pemboleh ubah, masukkan hanya konfigurasi frontend yang betul dan memang diperlukan. Nilai `VITE_*` boleh dimasukkan ke dalam bundle pelayar; JANGAN letakkan rahsia server seperti `FIREBASE_SERVICE_ACCOUNT_JSON`, `TURNSTILE_SECRET_KEY`, `GEMINI_API_KEY` atau token pentadbir dalam pemboleh ubah `VITE_*`.
5. Tekan Deploy. Gunakan URL `*.vercel.app` sebagai preview sahaja. Uji navigasi, paparan mudah alih dan konsol pelayar.

## Konfigurasi API SAFE
Selepas API dihoskan dengan selamat, tetapkan `VITE_REPORT_API_URL` kepada URL HTTPS API tersebut dan redeploy frontend. Backend perlu menetapkan `FRONTEND_ORIGINS` kepada domain Vercel sebenar, serta menyediakan `FIREBASE_PROJECT_ID`, `FIREBASE_STORAGE_BUCKET`, kelayakan Firebase Admin, `TURNSTILE_SECRET_KEY`, dan senarai pengguna staf yang dibenarkan. Jangan letakkan nilai rahsia ini di frontend.

## Semakan sebelum produksi
- Build penuh `npm run build` dan `npm run typecheck` lulus.
- API health check, laporan, lampiran, semakan status dan kawalan peranan diuji menggunakan data rekaan.
- Firebase Firestore/Storage rules dan pemilikan projek disemak.
- Turnstile, CORS, kadar had, dasar penyimpanan/pemadaman dan aliran eskalasi kes dikonfigurasikan.
- Jangan tukar domain rasmi atau gantikan laman lama sehingga semua ujian lulus.
