# KITABUDDY 2.0 — #JomCegahBuli

KITABUDDY 2.0 ialah versi pembangunan baharu berasaskan source code KITABUDDY sedia ada. Identiti dan modul pendidikan KITABUDDY dikekalkan, manakala **SAFE — School Anti-Bullying Framework for Empowerment** dimasukkan sebagai add-on/kerangka pelengkap.

> **Status:** Prototaip pembangunan. Jangan deploy kepada pengguna sebenar sebelum audit keselamatan, konfigurasi Firebase, peraturan akses dan proses respons kes disahkan oleh pemilik sistem/sekolah.

## Kandungan versi ini

- Mengekalkan struktur aplikasi dan modul pendidikan KITABUDDY asal.
- Menambah CTA awam `Laporkan Buli (Anonim)` pada halaman hadapan.
- Menambah halaman borang laporan berformat teks, foto, audio dan video.
- Menambah halaman penerangan add-on SAFE.
- Menyediakan SAFE API server berasingan untuk penerimaan laporan, semakan status menggunakan nombor rujukan/kod rahsia, senarai kes untuk petugas yang disahkan, pautan bukti sementara dan kemas kini status.
- Laporan serta bukti baharu menggunakan koleksi `safe_reports_v2` dan laluan Storage `safe-reports-v2/`; akses browser terus ditolak oleh contoh rules yang disediakan.
- Meletakkan alamat API dan kunci Turnstile frontend di dalam environment variables, bukan hard-coded.

## Teknologi

- Frontend: React 18, TypeScript, Vite, Tailwind CDN (seperti projek asal), Firebase Web SDK.
- API: Node.js, Express, Firebase Admin SDK, Multer, Helmet, CORS dan rate limiting.
- Penyimpanan SAFE: Firestore + Cloud Storage melalui Firebase Admin di server sahaja.
- Perlindungan bot: Cloudflare Turnstile diperlukan dalam persekitaran production.

## Menjalankan frontend

1. Pasang Node.js 20 atau lebih baharu.
2. Salin `.env.example` kepada `.env.local`.
3. Isi konfigurasi Firebase Web yang betul untuk projek KITABUDDY yang diluluskan. Jangan masukkan service-account private key ke frontend.
4. Tetapkan `VITE_REPORT_API_URL=http://localhost:8787` semasa pembangunan tempatan.
5. Jalankan `npm install`.
6. Jalankan `npm run dev`.

## Menjalankan API SAFE

1. Salin `server/.env.example` kepada `server/.env` atau tetapkan environment variables di hosting.
2. Konfigurasikan Firebase Admin melalui `FIREBASE_SERVICE_ACCOUNT_JSON` atau Application Default Credentials.
3. Tetapkan `FIREBASE_PROJECT_ID` dan `FIREBASE_STORAGE_BUCKET` kepada projek yang diluluskan.
4. Tetapkan `FRONTEND_ORIGINS` kepada domain frontend yang betul.
5. Untuk production, tetapkan `NODE_ENV=production`, `TURNSTILE_SECRET_KEY`, dan `SAFE_ADMIN_EMAILS` atau custom claims yang dikeluarkan secara trusted oleh server.
6. Jalankan `npm run server`.

Untuk kedua-dua proses secara serentak, `npm run dev:full` boleh digunakan selepas dependencies dipasang. Pastikan API boleh membaca `server/.env`; secara lalai server memuatkan fail itu. Untuk hosting yang menyediakan environment variables, tetapkan nilainya terus pada platform hosting. API tidak akan menyimpan laporan jika Firebase Admin belum disediakan. Production menolak laporan apabila Turnstile belum dikonfigurasikan.

## API ringkas

- `GET /api/health` — status perkhidmatan (tidak mendedahkan rahsia).
- `GET /api/features` dan `GET /api/settings/public` — bacaan konfigurasi ciri/mod penyelenggaraan tanpa medan pentadbiran sensitif.
- `POST /api/reports` — laporan anonim; multipart form, lampiran pilihan mengikut jenis laporan.
- `POST /api/reports/status` — semakan status menggunakan `reference` dan `trackingCode`.
- `GET /api/admin/reports` — senarai laporan SAFE v2 kepada petugas yang token Firebase-nya disahkan dan mempunyai kebenaran.
- `GET /api/admin/reports/:reference/evidence` — signed URL bukti yang luput selepas 5 minit; akses diaudit.
- `PATCH /api/admin/reports/:reference/status` — kemas kini status SAFE v2 untuk pentadbir/kaunselor yang dibenarkan.
- `GET/POST /api/admin/legacy-reports`, `PATCH/DELETE /api/admin/legacy-reports/:reportId` — pengurusan laporan lama melalui API staf.
- `/api/admin/users` — pengurusan akaun melalui API; operasi mutasi dihadkan kepada pentadbir.
- `PATCH /api/admin/features/:featureId` dan `PATCH /api/admin/settings/maintenance` — kemas kini ciri/maintenance melalui API pentadbir.
- `POST /api/analytics/features/:featureId/usage` dan `GET /api/admin/analytics/features` — statistik penggunaan dengan bacaan dashboard dilindungi.

## Semakan penting sebelum pelancaran

- Semak Firebase Auth, Firestore Rules, Storage Rules dan sekatan API key untuk aplikasi web.
- Jangan gunakan PIN admin, PIN backend atau penyemakan kata laluan di Firestore daripada versi lama sebagai kawalan keselamatan production. Pengurusan pengguna, laporan lama, tetapan ciri dan mod penyelenggaraan dalam versi kerja ini menggunakan API server; akses chat/profil dan Rules berkaitan masih perlu diaudit.
- Jangan dedahkan API key AI, token Telegram atau rahsia servis lain dalam bundle frontend. Semua integrasi sensitif mesti melalui API server.
- Tetapkan dan uji kadar had, Turnstile, dasar retention/pemadaman, log audit dan aliran eskalasi kes berisiko.
- Semak semua kandungan, pautan luaran, modul asal dan dasar respons kes bersama pihak sekolah.
- Uji sandaran/pemulihan, akses berdasarkan peranan, input fail, fail berbahaya, media persendirian dan ujian penetrasi sebelum pelancaran.

## Dokumen pendamping

- `docs/UPGRADE_ROADMAP.md` — keputusan skop dan susunan pelaksanaan.
- `docs/MIGRATION_MAP.md` — pemetaan modul lama kepada KITABUDDY 2.0.
- `docs/SECURITY_REVIEW.md` — isu keselamatan serta tindakan pembetulan.
- `firebase/firestore.safe.rules.example` dan `firebase/storage.safe.rules.example` — contoh kawalan akses untuk data SAFE v2.

## Tentang projek SAFE lama

Projek SAFE lama digunakan sebagai sumber rujukan fungsi dan aliran kerja. Servis/token lama tidak disalin ke frontend KITABUDDY 2.0. Penggabungan penuh data atau fungsi sedia ada perlu dibuat selepas inventori koleksi, format data, pemilikan Firebase project dan dasar akses disahkan.
