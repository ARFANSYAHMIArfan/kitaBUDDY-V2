import dotenv from 'dotenv';
import crypto from 'node:crypto';
import path from 'node:path';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import multer from 'multer';
import rateLimit from 'express-rate-limit';
import { initializeApp, cert, applicationDefault, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { getStorage } from 'firebase-admin/storage';

dotenv.config({ path: process.env.API_ENV_FILE || new URL('./.env', import.meta.url).pathname });

const app = express();
const PORT = Number(process.env.PORT || 8787);
const NODE_ENV = process.env.NODE_ENV || 'development';
const isProduction = NODE_ENV === 'production';
app.set('trust proxy', Number(process.env.TRUST_PROXY_HOPS || 1));
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));

const allowedOrigins = (process.env.FRONTEND_ORIGINS || 'http://localhost:3000,http://localhost:5173')
  .split(',').map(v => v.trim()).filter(Boolean);
app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
    return callback(new Error('Origin tidak dibenarkan.'));
  },
  methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  maxAge: 600,
}));
app.use(express.json({ limit: '32kb' }));

const storage = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024, files: 1, fields: 20, fieldSize: 8000 },
  fileFilter(_req, file, callback) {
    const allowed = new Set([
      'image/jpeg', 'image/png', 'image/webp',
      'audio/webm', 'audio/ogg', 'audio/wav', 'audio/mpeg', 'audio/mp4', 'audio/aac',
      'video/webm', 'video/mp4', 'video/quicktime',
    ]);
    if (!allowed.has(file.mimetype)) return callback(new Error('Jenis fail tidak disokong.'));
    callback(null, true);
  },
});

const anonymousLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: Number(process.env.REPORT_RATE_LIMIT_PER_HOUR || 10),
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Terlalu banyak percubaan. Sila cuba semula kemudian atau gunakan saluran bantuan sekolah.' },
});
const manualLoginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Terlalu banyak percubaan log masuk. Sila tunggu sebelum mencuba lagi.' },
});
const statusLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Terlalu banyak percubaan semakan status. Sila cuba semula kemudian.' },
});

let firebaseReady = false;
let firebaseInitError = '';
let db;
let bucket;
let auth;
try {
  const serviceAccountRaw = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  const projectId = process.env.FIREBASE_PROJECT_ID;
  const storageBucket = process.env.FIREBASE_STORAGE_BUCKET;
  const hasWorkloadCredentials = Boolean(process.env.GOOGLE_APPLICATION_CREDENTIALS || process.env.K_SERVICE || process.env.FIREBASE_USE_ADC === 'true');
  if (!projectId || !storageBucket || (!serviceAccountRaw && !hasWorkloadCredentials)) {
    throw new Error('Tetapkan project ID, bucket dan kredensial Firebase Admin pada server.');
  }
  const credential = serviceAccountRaw
    ? cert(JSON.parse(serviceAccountRaw))
    : applicationDefault();
  if (!getApps().length) {
    initializeApp({ credential, projectId: projectId || undefined, storageBucket: storageBucket || undefined });
  }
  db = getFirestore();
  auth = getAuth();
  bucket = getStorage().bucket(storageBucket || undefined);
  firebaseReady = Boolean(db && auth && bucket);
} catch (error) {
  firebaseInitError = error instanceof Error ? error.message : 'Konfigurasi Firebase Admin tidak lengkap.';
  console.error('Firebase Admin belum tersedia:', firebaseInitError);
}

const categories = new Set(['physical', 'verbal', 'social', 'cyber', 'other']);
const reportTypes = new Set(['text', 'photo', 'audio', 'video']);
const statuses = new Set(['Diterima', 'Dalam Semakan', 'Tindakan Susulan', 'Ditutup']);
const safeAdminEmails = new Set((process.env.SAFE_ADMIN_EMAILS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean));
const manualAdminIds = new Set((process.env.MANUAL_ADMIN_IDS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean));
const randomToken = (bytes = 24) => crypto.randomBytes(bytes).toString('base64url');
const sha256 = value => crypto.createHash('sha256').update(String(value)).digest('hex');
const constantTimeEqual = (a, b) => {
  const aBuf = Buffer.from(String(a));
  const bBuf = Buffer.from(String(b));
  return aBuf.length === bBuf.length && crypto.timingSafeEqual(aBuf, bBuf);
};
const cleanString = (value, max) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const publicReference = () => `KB-${new Date().toISOString().slice(0, 10).replaceAll('-', '')}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

async function verifyTurnstile(token, remoteip) {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) {
    if (isProduction) return { ok: false, reason: 'Pengesahan anti-robot belum dikonfigurasikan.' };
    return { ok: true, reason: 'Development mode: Turnstile tidak dikonfigurasikan.' };
  }
  if (!token) return { ok: false, reason: 'Pengesahan keselamatan diperlukan.' };
  const form = new URLSearchParams({ secret, response: token });
  if (remoteip) form.set('remoteip', remoteip);
  try {
    const response = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: form });
    const result = await response.json();
    return { ok: Boolean(result.success), reason: result.success ? '' : 'Pengesahan keselamatan gagal.' };
  } catch {
    return { ok: false, reason: 'Tidak dapat mengesahkan perlindungan anti-robot.' };
  }
}

function requireFirebase(_req, res, next) {
  if (!firebaseReady) return res.status(503).json({ message: 'Backend belum dikonfigurasikan dengan Firebase Admin.' });
  next();
}

async function requireStaff(req, res, next) {
  if (!firebaseReady) return res.status(503).json({ message: 'Backend belum dikonfigurasikan.' });
  const header = req.headers.authorization || '';
  const match = header.match(/^Bearer\s+(.+)$/i);
  if (!match) return res.status(401).json({ message: 'Token staf diperlukan.' });
  try {
    const decoded = await auth.verifyIdToken(match[1], true);
    const email = String(decoded.email || '').toLowerCase();
    const role = String(decoded.role || decoded.safeRole || '').toLowerCase();
    const allowlisted = safeAdminEmails.has(email);
    const hasStaffClaim = ['admin', 'school_admin', 'counselor'].includes(role);
    if (!allowlisted && !hasStaffClaim) return res.status(403).json({ message: 'Akses ini hanya untuk petugas yang diberi kuasa.' });
    req.staff = { uid: decoded.uid, email, role: role || (allowlisted ? 'admin' : 'staff') };
    next();
  } catch {
    return res.status(401).json({ message: 'Sesi staf tidak sah atau telah tamat.' });
  }
}

function requireCaseManager(req, res, next) {
  const manager = ['admin', 'school_admin', 'counselor'].includes(req.staff?.role) || safeAdminEmails.has(req.staff?.email);
  if (!manager) return res.status(403).json({ message: 'Hanya pentadbir atau kaunselor yang diberi kuasa boleh mengubah status kes.' });
  next();
}

function requireUserAdmin(req, res, next) {
  const isAdmin = ['admin', 'school_admin'].includes(req.staff?.role) || safeAdminEmails.has(req.staff?.email);
  if (!isAdmin) return res.status(403).json({ message: 'Pengurusan akaun hanya boleh dilakukan oleh pentadbir yang diberi kuasa.' });
  next();
}

const safeRoleFromClaims = (claims = {}) => {
  const role = String(claims.role || claims.safeRole || '').toLowerCase();
  if (claims.admin === true || ['admin', 'school_admin'].includes(role)) return 'admin';
  if (role === 'counselor') return 'counselor';
  if (role === 'teacher') return 'teacher';
  return 'student';
};

app.post('/api/auth/manual', requireFirebase, manualLoginLimiter, async (req, res) => {
  try {
    const studentId = cleanString(req.body?.studentId, 120);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!studentId || password.length < 1 || password.length > 300) return res.status(400).json({ message: 'ID dan kata laluan diperlukan.' });
    const normalizedId = studentId.toLowerCase();
    const matchingUsers = await db.collection('users').where('studentId', '==', studentId).limit(2).get();
    if (matchingUsers.empty || matchingUsers.size !== 1) return res.status(401).json({ message: 'ID atau kata laluan tidak sah.' });
    const userDoc = matchingUsers.docs[0];
    const userData = userDoc.data();
    let validPassword = false;
    const savedHash = String(userData.passwordHash || '');
    const savedSalt = String(userData.passwordSalt || '');
    if (savedHash && savedSalt) {
      const candidate = crypto.scryptSync(password, savedSalt, 64).toString('hex');
      validPassword = constantTimeEqual(candidate, savedHash);
    } else if (typeof userData.password === 'string') {
      // Compatibility bridge only: on a successful login, migrate legacy plaintext to scrypt hash.
      validPassword = constantTimeEqual(password, userData.password);
    }
    if (!validPassword) return res.status(401).json({ message: 'ID atau kata laluan tidak sah.' });

    const authUid = String(userData.authUid || `kb-${sha256(normalizedId).slice(0, 40)}`);
    let authUser;
    try { authUser = await auth.getUser(authUid); }
    catch (error) {
      if (error?.code !== 'auth/user-not-found') throw error;
      authUser = await auth.createUser({ uid: authUid, displayName: cleanString(userData.StudentName || userData.name || studentId, 120) || studentId });
    }
    // Never grant a privileged role merely because the Firestore user document says "admin".
    // Manual admin IDs must be explicitly configured in this private server environment.
    const role = manualAdminIds.has(normalizedId) ? 'admin' : 'student';
    await auth.setCustomUserClaims(authUser.uid, { ...(authUser.customClaims || {}), role, safeRole: role });
    const customToken = await auth.createCustomToken(authUser.uid, { role, safeRole: role });

    const updates = { authUid: authUser.uid, role, lastLoginAt: FieldValue.serverTimestamp() };
    if (!savedHash || !savedSalt) {
      const salt = randomToken(16);
      updates.passwordSalt = salt;
      updates.passwordHash = crypto.scryptSync(password, salt, 64).toString('hex');
      updates.password = FieldValue.delete();
    }
    await userDoc.ref.update(updates);
    res.json({ customToken, studentId, name: cleanString(userData.StudentName || userData.name || studentId, 120), role });
  } catch {
    res.status(500).json({ message: 'Log masuk tidak dapat diproses. Sila cuba semula kemudian.' });
  }
});

app.post('/api/auth/sync-google-role', requireFirebase, manualLoginLimiter, async (req, res) => {
  try {
    const idToken = cleanString(req.body?.idToken, 10000);
    if (!idToken) return res.status(400).json({ message: 'Token Firebase diperlukan.' });
    const decoded = await auth.verifyIdToken(idToken, true);
    const email = String(decoded.email || '').toLowerCase();
    let role = safeRoleFromClaims(decoded);
    if (safeAdminEmails.has(email)) {
      const authUser = await auth.getUser(decoded.uid);
      await auth.setCustomUserClaims(decoded.uid, { ...(authUser.customClaims || {}), role: 'admin', safeRole: 'admin' });
      role = 'admin';
    }
    res.json({ role });
  } catch {
    res.status(401).json({ message: 'Sesi Google tidak sah atau tidak dapat disahkan.' });
  }
});

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'KITABUDDY 2.0 SAFE API', firebaseReady, reportingEnabled: firebaseReady && (Boolean(process.env.TURNSTILE_SECRET_KEY) || !isProduction), environment: NODE_ENV });
});

// Public, read-only configuration endpoints. The browser never writes these records directly.
app.get('/api/features', requireFirebase, async (_req, res) => {
  try {
    const snapshot = await db.collection('features').get();
    const features = {};
    snapshot.forEach(doc => {
      const data = doc.data() || {};
      features[doc.id] = {
        title: cleanString(data.title, 120),
        status: ['Active', 'Coming Soon', 'Maintenance'].includes(data.status) ? data.status : 'Active',
        message: cleanString(data.message, 500),
      };
    });
    res.json({ features });
  } catch {
    res.status(500).json({ message: 'Konfigurasi ciri tidak dapat dimuatkan.' });
  }
});

app.get('/api/settings/public', requireFirebase, async (_req, res) => {
  try {
    const snapshot = await db.collection('settings').doc('general').get();
    res.json({ maintenanceMode: snapshot.exists ? Boolean(snapshot.data()?.maintenanceMode) : false });
  } catch {
    res.status(500).json({ message: 'Tetapan sistem tidak dapat dimuatkan.' });
  }
});

app.patch('/api/admin/features/:featureId', requireStaff, requireUserAdmin, async (req, res) => {
  try {
    const featureId = cleanString(req.params.featureId, 100);
    if (!/^[a-zA-Z0-9_-]+$/.test(featureId)) return res.status(400).json({ message: 'ID ciri tidak sah.' });
    const title = cleanString(req.body?.title, 120);
    const status = cleanString(req.body?.status, 30);
    const message = cleanString(req.body?.message, 500);
    if (!title || !['Active', 'Coming Soon', 'Maintenance'].includes(status)) return res.status(400).json({ message: 'Nama atau status ciri tidak sah.' });
    await db.collection('features').doc(featureId).set({ title, status, message, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    await db.collection('user_admin_audit_v2').add({ action: 'feature_updated', featureId, status, actorUid: req.staff.uid, actorEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    res.json({ ok: true, featureId, title, status, message });
  } catch {
    res.status(500).json({ message: 'Tetapan ciri tidak dapat disimpan.' });
  }
});

app.patch('/api/admin/settings/maintenance', requireStaff, requireUserAdmin, async (req, res) => {
  try {
    if (typeof req.body?.enabled !== 'boolean') return res.status(400).json({ message: 'Nilai mod penyelenggaraan tidak sah.' });
    await db.collection('settings').doc('general').set({ maintenanceMode: req.body.enabled, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    await db.collection('user_admin_audit_v2').add({ action: 'maintenance_mode_updated', enabled: req.body.enabled, actorUid: req.staff.uid, actorEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    res.json({ ok: true, maintenanceMode: req.body.enabled });
  } catch {
    res.status(500).json({ message: 'Tetapan penyelenggaraan tidak dapat disimpan.' });
  }
});

const legacyReportStatuses = new Set(['Baru', 'Siasatan', 'Selesai']);
app.get('/api/admin/legacy-reports', requireStaff, requireCaseManager, async (_req, res) => {
  try {
    const snapshot = await db.collection('reports').limit(300).get();
    const reports = snapshot.docs.map(doc => {
      const data = doc.data() || {};
      return {
        id: doc.id,
        student: cleanString(data.student, 120),
        class: cleanString(data.class, 80),
        issue: cleanString(data.issue, 2000),
        status: legacyReportStatuses.has(data.status) ? data.status : 'Baru',
        date: data.date?.toDate ? data.date.toDate().toISOString() : (typeof data.date === 'string' ? cleanString(data.date, 80) : 'Masa tidak tersedia'),
      };
    }).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    res.json({ reports });
  } catch {
    res.status(500).json({ message: 'Laporan lama tidak dapat dimuatkan.' });
  }
});

app.post('/api/admin/legacy-reports', requireStaff, requireCaseManager, async (req, res) => {
  try {
    const student = cleanString(req.body?.student, 120);
    const studentClass = cleanString(req.body?.class, 80);
    const issue = cleanString(req.body?.issue, 2000);
    if (!student || !studentClass || issue.length < 5) return res.status(400).json({ message: 'Nama murid, kelas dan keterangan diperlukan.' });
    const report = { student, class: studentClass, issue, status: 'Baru', date: FieldValue.serverTimestamp(), createdByUid: req.staff.uid, createdByEmail: req.staff.email };
    const created = await db.collection('reports').add(report);
    await db.collection('user_admin_audit_v2').add({ action: 'legacy_report_created', targetId: created.id, actorUid: req.staff.uid, actorEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    res.status(201).json({ id: created.id, student, class: studentClass, issue, status: 'Baru', date: new Date().toISOString() });
  } catch {
    res.status(500).json({ message: 'Laporan tidak dapat ditambah.' });
  }
});

app.patch('/api/admin/legacy-reports/:reportId/status', requireStaff, requireCaseManager, async (req, res) => {
  try {
    const reportId = cleanString(req.params.reportId, 140);
    const status = cleanString(req.body?.status, 30);
    if (!legacyReportStatuses.has(status)) return res.status(400).json({ message: 'Status laporan tidak sah.' });
    const ref = db.collection('reports').doc(reportId);
    const snapshot = await ref.get();
    if (!snapshot.exists) return res.status(404).json({ message: 'Laporan tidak dijumpai.' });
    const previousStatus = snapshot.data()?.status || '';
    await ref.update({ status, updatedAt: FieldValue.serverTimestamp(), updatedByUid: req.staff.uid });
    await db.collection('user_admin_audit_v2').add({ action: 'legacy_report_status_updated', targetId: reportId, oldStatus: previousStatus, newStatus: status, actorUid: req.staff.uid, actorEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    res.json({ ok: true, id: reportId, status });
  } catch {
    res.status(500).json({ message: 'Status laporan tidak dapat dikemas kini.' });
  }
});

app.delete('/api/admin/legacy-reports/:reportId', requireStaff, requireCaseManager, async (req, res) => {
  try {
    const reportId = cleanString(req.params.reportId, 140);
    const ref = db.collection('reports').doc(reportId);
    const snapshot = await ref.get();
    if (!snapshot.exists) return res.status(404).json({ message: 'Laporan tidak dijumpai.' });
    await db.collection('user_admin_audit_v2').add({ action: 'legacy_report_deleted', targetId: reportId, actorUid: req.staff.uid, actorEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    await ref.delete();
    res.json({ ok: true, id: reportId });
  } catch {
    res.status(500).json({ message: 'Laporan tidak dapat dipadam.' });
  }
});

app.post('/api/analytics/features/:featureId/usage', requireFirebase, rateLimit({ windowMs: 60 * 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }), async (req, res) => {
  try {
    const featureId = cleanString(req.params.featureId, 100);
    if (!/^[a-zA-Z0-9_-]+$/.test(featureId)) return res.status(400).json({ message: 'ID ciri tidak sah.' });
    await db.collection('analytics').doc('feature_usage').set({ [featureId]: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    res.status(204).end();
  } catch {
    res.status(500).json({ message: 'Statistik penggunaan tidak dapat direkodkan.' });
  }
});

app.get('/api/admin/analytics/features', requireStaff, requireUserAdmin, async (_req, res) => {
  try {
    const snapshot = await db.collection('analytics').doc('feature_usage').get();
    res.json({ usage: snapshot.exists ? snapshot.data() : {} });
  } catch {
    res.status(500).json({ message: 'Statistik penggunaan tidak dapat dimuatkan.' });
  }
});

app.post('/api/reports', requireFirebase, anonymousLimiter, storage.single('media'), async (req, res) => {
  let uploadedMediaPath = '';
  try {
    // Invisible honeypot: spam submissions are silently rejected.
    if (cleanString(req.body?.website, 300)) return res.status(400).json({ message: 'Permintaan tidak dapat diproses.' });
    if (String(req.body?.privacyAccepted).toLowerCase() !== 'true') return res.status(400).json({ message: 'Pengesahan maklumat privasi diperlukan.' });
    const reportType = cleanString(req.body?.reportType, 10);
    const category = cleanString(req.body?.category, 20);
    const description = cleanString(req.body?.description, 5000);
    const incidentDate = cleanString(req.body?.incidentDate, 10);
    const location = cleanString(req.body?.location, 120);
    const urgent = String(req.body?.urgent).toLowerCase() === 'true';
    const token = cleanString(req.body?.turnstileToken, 4000);
    if (!reportTypes.has(reportType)) return res.status(400).json({ message: 'Jenis laporan tidak sah.' });
    if (!categories.has(category)) return res.status(400).json({ message: 'Kategori laporan tidak sah.' });
    if (reportType === 'text' && description.length < 10) return res.status(400).json({ message: 'Penerangan laporan terlalu pendek.' });
    if (reportType !== 'text' && !req.file) return res.status(400).json({ message: 'Fail bukti diperlukan untuk jenis laporan ini.' });
    if (req.file && reportType === 'photo' && !req.file.mimetype.startsWith('image/')) return res.status(400).json({ message: 'Fail foto tidak sah.' });
    if (req.file && reportType === 'audio' && !req.file.mimetype.startsWith('audio/')) return res.status(400).json({ message: 'Fail audio tidak sah.' });
    if (req.file && reportType === 'video' && !req.file.mimetype.startsWith('video/')) return res.status(400).json({ message: 'Fail video tidak sah.' });
    if (incidentDate && !/^\d{4}-\d{2}-\d{2}$/.test(incidentDate)) return res.status(400).json({ message: 'Tarikh kejadian tidak sah.' });
    const captcha = await verifyTurnstile(token, req.ip);
    if (!captcha.ok) return res.status(400).json({ message: captcha.reason });

    const reference = publicReference();
    const trackingCode = randomToken(12);
    let mediaPath = '';
    let mediaMimeType = '';
    if (req.file) {
      const extension = path.extname(req.file.originalname || '').toLowerCase().replace(/[^.a-z0-9]/g, '').slice(0, 10) || '.bin';
      mediaPath = `safe-reports-v2/${reference}/evidence${extension}`;
      uploadedMediaPath = mediaPath;
      mediaMimeType = req.file.mimetype;
      await bucket.file(mediaPath).save(req.file.buffer, {
        resumable: false,
        metadata: {
          contentType: req.file.mimetype,
          cacheControl: 'private, no-store, max-age=0',
          contentDisposition: 'attachment',
          metadata: { source: 'kitabuddy-safe-v2', reportReference: reference },
        },
      });
    }
    await db.collection('safe_reports_v2').doc(reference).create({
      reference,
      trackingCodeHash: sha256(trackingCode),
      reportType,
      category,
      description,
      incidentDate: incidentDate || null,
      location,
      urgent,
      status: 'Diterima',
      publicUpdate: 'Laporan diterima untuk semakan awal.',
      mediaPath: mediaPath || null,
      mediaMimeType: mediaMimeType || null,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      source: 'kitabuddy-safe-v2',
    });
    uploadedMediaPath = '';
    res.status(201).json({ reference, trackingCode, message: 'Laporan diterima untuk semakan awal.' });
  } catch (error) {
    if (uploadedMediaPath && bucket) { try { await bucket.file(uploadedMediaPath).delete({ ignoreNotFound: true }); } catch { /* cleanup is best effort */ } }
    console.error('Report submission error:', error instanceof Error ? error.message : 'unknown error');
    res.status(500).json({ message: 'Laporan tidak dapat disimpan. Sila gunakan saluran bantuan sekolah jika bantuan diperlukan segera.' });
  }
});

app.post('/api/reports/status', requireFirebase, statusLimiter, async (req, res) => {
  try {
    const reference = cleanString(req.body?.reference, 80);
    const trackingCode = cleanString(req.body?.trackingCode, 100);
    if (!reference || !trackingCode) return res.status(400).json({ message: 'Nombor rujukan dan kod semakan diperlukan.' });
    const snapshot = await db.collection('safe_reports_v2').doc(reference).get();
    if (!snapshot.exists) return res.status(404).json({ message: 'Nombor rujukan atau kod semakan tidak sah.' });
    const data = snapshot.data();
    const suppliedHash = sha256(trackingCode);
    if (!constantTimeEqual(suppliedHash, data.trackingCodeHash || '')) return res.status(404).json({ message: 'Nombor rujukan atau kod semakan tidak sah.' });
    res.json({
      reference,
      status: data.status || 'Diterima',
      publicUpdate: data.publicUpdate || '',
      createdAt: data.createdAt?.toDate ? data.createdAt.toDate().toISOString() : null,
    });
  } catch {
    res.status(500).json({ message: 'Semakan status gagal. Sila cuba semula kemudian.' });
  }
});

app.get('/api/admin/users', requireStaff, requireUserAdmin, async (_req, res) => {
  try {
    const snapshot = await db.collection('users').limit(300).get();
    const users = await Promise.all(snapshot.docs.map(async doc => {
      const d = doc.data();
      const authUid = cleanString(d.authUid || (d.provider === 'google' ? doc.id : ''), 160);
      let role = cleanString(d.role || 'student', 40);
      if (authUid) {
        try {
          const authUser = await auth.getUser(authUid);
          const claims = authUser.customClaims || {};
          role = claims.admin === true || ['admin', 'school_admin'].includes(String(claims.role || claims.safeRole || '').toLowerCase())
            ? 'admin'
            : ['teacher', 'counselor'].includes(String(claims.role || claims.safeRole || '').toLowerCase())
              ? String(claims.role || claims.safeRole).toLowerCase()
              : 'student';
        } catch { /* Keep sanitized profile role when a legacy account has not been linked yet. */ }
      }
      return {
        docId: doc.id,
        studentId: cleanString(d.studentId, 120),
        name: cleanString(d.StudentName || d.name || d.studentId, 120),
        role,
        createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : null,
      };
    }));
    res.json({ users });
  } catch {
    res.status(500).json({ message: 'Senarai pengguna tidak dapat dimuatkan.' });
  }
});

app.post('/api/admin/users', requireStaff, requireUserAdmin, async (req, res) => {
  try {
    const studentId = cleanString(req.body?.studentId, 120);
    const name = cleanString(req.body?.name, 120);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const requestedRole = cleanString(req.body?.role || 'student', 40).toLowerCase();
    const normalizedId = studentId.toLowerCase();
    if (!studentId || !name) return res.status(400).json({ message: 'Nama dan ID pengguna diperlukan.' });
    if (password.length < 10 || password.length > 300) return res.status(400).json({ message: 'Kata laluan sementara mesti sekurang-kurangnya 10 aksara.' });
    if (!['student', 'admin'].includes(requestedRole)) return res.status(400).json({ message: 'Peranan baharu mesti student atau admin.' });
    if (requestedRole === 'admin' && !manualAdminIds.has(normalizedId)) return res.status(403).json({ message: 'Untuk memberikan peranan admin, ID mesti ditambah ke MANUAL_ADMIN_IDS pada server terlebih dahulu.' });
    const existing = await db.collection('users').where('studentId', '==', studentId).limit(1).get();
    if (!existing.empty) return res.status(409).json({ message: 'ID pengguna telah wujud.' });
    const salt = randomToken(16);
    const passwordHash = crypto.scryptSync(password, salt, 64).toString('hex');
    const authUid = `kb-${sha256(normalizedId).slice(0, 40)}`;
    const role = requestedRole === 'admin' ? 'admin' : 'student';
    try { await auth.getUser(authUid); }
    catch (error) {
      if (error?.code !== 'auth/user-not-found') throw error;
      await auth.createUser({ uid: authUid, displayName: name });
    }
    const authUser = await auth.getUser(authUid);
    await auth.setCustomUserClaims(authUid, { ...(authUser.customClaims || {}), role, safeRole: role });
    const created = await db.collection('users').add({ studentId, name, role, authUid, passwordSalt: salt, passwordHash, createdAt: FieldValue.serverTimestamp() });
    await db.collection('user_admin_audit_v2').add({ action: 'user_created', targetDocId: created.id, studentId, role, actorUid: req.staff.uid, actorEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    res.status(201).json({ user: { docId: created.id, studentId, name, role } });
  } catch {
    res.status(500).json({ message: 'Pengguna tidak dapat ditambah.' });
  }
});

app.patch('/api/admin/users/:docId/role', requireStaff, requireUserAdmin, async (req, res) => {
  try {
    const docId = cleanString(req.params.docId, 160);
    const roleRaw = cleanString(req.body?.role, 40).toLowerCase();
    if (!['student', 'admin'].includes(roleRaw)) return res.status(400).json({ message: 'Peranan tidak sah.' });
    const ref = db.collection('users').doc(docId);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ message: 'Pengguna tidak dijumpai.' });
    const data = snap.data();
    const normalizedId = cleanString(data.studentId, 120).toLowerCase();
    if (roleRaw === 'admin' && !(data.provider === 'google' ? safeAdminEmails.has(normalizedId) : manualAdminIds.has(normalizedId))) return res.status(403).json({ message: 'Untuk memberikan peranan admin, ID atau e-mel mesti berada dalam allowlist server yang sepadan.' });
    const role = roleRaw === 'admin' ? 'admin' : 'student';
    await ref.update({ role, updatedAt: FieldValue.serverTimestamp() });
    const linkedAuthUid = data.authUid || (data.provider === 'google' ? docId : '');
    if (linkedAuthUid) {
      const authUser = await auth.getUser(linkedAuthUid);
      await auth.setCustomUserClaims(linkedAuthUid, { ...(authUser.customClaims || {}), role, safeRole: role });
      await auth.revokeRefreshTokens(linkedAuthUid);
    }
    await db.collection('user_admin_audit_v2').add({ action: 'user_role_updated', targetDocId: docId, studentId: data.studentId || '', newRole: role, actorUid: req.staff.uid, actorEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    res.json({ ok: true, docId, role });
  } catch {
    res.status(500).json({ message: 'Peranan pengguna tidak dapat dikemas kini.' });
  }
});

app.delete('/api/admin/users/:docId', requireStaff, requireUserAdmin, async (req, res) => {
  try {
    const docId = cleanString(req.params.docId, 160);
    const ref = db.collection('users').doc(docId);
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ message: 'Pengguna tidak dijumpai.' });
    const data = snap.data();
    const linkedAuthUid = data.authUid || (data.provider === 'google' ? docId : '');
    if (linkedAuthUid) {
      try { await auth.revokeRefreshTokens(linkedAuthUid); } catch { /* token may not exist */ }
      try { await auth.deleteUser(linkedAuthUid); } catch (error) { if (error?.code !== 'auth/user-not-found') throw error; }
    }
    await db.collection('user_admin_audit_v2').add({ action: 'user_deleted', targetDocId: docId, studentId: data.studentId || '', actorUid: req.staff.uid, actorEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    await ref.delete();
    res.json({ ok: true, docId });
  } catch {
    res.status(500).json({ message: 'Pengguna tidak dapat dipadam.' });
  }
});

app.get('/api/admin/reports', requireStaff, async (req, res) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit || 100), 1), 200);
    const snapshot = await db.collection('safe_reports_v2').orderBy('createdAt', 'desc').limit(limit).get();
    const reports = snapshot.docs.map(doc => {
      const d = doc.data();
      return {
        reference: d.reference,
        reportType: d.reportType,
        category: d.category,
        description: d.description,
        incidentDate: d.incidentDate,
        location: d.location,
        urgent: Boolean(d.urgent),
        status: d.status,
        publicUpdate: d.publicUpdate || '',
        hasMedia: Boolean(d.mediaPath),
        mediaMimeType: d.mediaMimeType || null,
        createdAt: d.createdAt?.toDate ? d.createdAt.toDate().toISOString() : null,
        updatedAt: d.updatedAt?.toDate ? d.updatedAt.toDate().toISOString() : null,
      };
    });
    res.json({ reports });
  } catch {
    res.status(500).json({ message: 'Senarai laporan tidak dapat dimuatkan.' });
  }
});

app.get('/api/admin/reports/:reference/evidence', requireStaff, async (req, res) => {
  try {
    const snapshot = await db.collection('safe_reports_v2').doc(cleanString(req.params.reference, 80)).get();
    if (!snapshot.exists || !snapshot.data().mediaPath) return res.status(404).json({ message: 'Bukti tidak dijumpai.' });
    const [url] = await bucket.file(snapshot.data().mediaPath).getSignedUrl({ action: 'read', expires: Date.now() + 5 * 60 * 1000, version: 'v4' });
    await db.collection('safe_report_audit_v2').add({ action: 'evidence_link_created', reference: req.params.reference, staffUid: req.staff.uid, staffEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    res.json({ url, expiresInSeconds: 300 });
  } catch {
    res.status(500).json({ message: 'Bukti tidak dapat dibuka.' });
  }
});

app.patch('/api/admin/reports/:reference/status', requireStaff, requireCaseManager, async (req, res) => {
  try {
    const reference = cleanString(req.params.reference, 80);
    const status = cleanString(req.body?.status, 40);
    const publicUpdate = cleanString(req.body?.publicUpdate, 500);
    if (!statuses.has(status)) return res.status(400).json({ message: 'Status laporan tidak sah.' });
    const reportRef = db.collection('safe_reports_v2').doc(reference);
    const snap = await reportRef.get();
    if (!snap.exists) return res.status(404).json({ message: 'Laporan tidak dijumpai.' });
    await reportRef.update({ status, publicUpdate, updatedAt: FieldValue.serverTimestamp() });
    await db.collection('safe_report_audit_v2').add({ action: 'status_updated', reference, oldStatus: snap.data().status || '', newStatus: status, staffUid: req.staff.uid, staffEmail: req.staff.email, createdAt: FieldValue.serverTimestamp() });
    res.json({ ok: true, reference, status, publicUpdate });
  } catch {
    res.status(500).json({ message: 'Status laporan tidak dapat dikemas kini.' });
  }
});

app.use((error, _req, res, _next) => {
  if (error instanceof multer.MulterError) {
    const message = error.code === 'LIMIT_FILE_SIZE' ? 'Saiz fail maksimum ialah 15 MB.' : 'Fail lampiran tidak dapat diproses.';
    return res.status(400).json({ message });
  }
  if (error) return res.status(400).json({ message: error.message || 'Permintaan tidak sah.' });
  return res.status(500).json({ message: 'Ralat pelayan.' });
});

app.listen(PORT, () => {
  console.log(`KITABUDDY 2.0 SAFE API berjalan pada port ${PORT} (${NODE_ENV}).`);
  if (!firebaseReady) console.warn('Firebase belum dikonfigurasikan; API tidak akan menyimpan laporan.', firebaseInitError ? '(butiran tidak dipaparkan)' : '');
  if (isProduction && !process.env.TURNSTILE_SECRET_KEY) console.warn('AMARAN: TURNSTILE_SECRET_KEY belum ditetapkan; penghantaran anonim akan ditolak.');
});
