# Status Pelaksanaan — KITABUDDY 2.0 + SAFE

## Telah dimasukkan dalam source code

- Kekalkan shell, navigasi dan modul pembelajaran sedia ada KITABUDDY.
- Tambah tindakan pelaporan anonim pada landing page dan menu.
- Tambah borang laporan teks/foto/audio/video dengan pengesahan privasi, had media dan semakan status menggunakan rujukan + kod rahsia.
- Tambah halaman SAFE — School Anti-Bullying Framework for Empowerment — sebagai add-on/kerangka pelengkap KITABUDDY.
- Tambah panduan awal sokongan mangsa, tindakan saksi dan bimbingan perubahan tingkah laku tanpa pelabelan kekal; panduan ini bukan pengganti SOP sekolah.
- Tambah dashboard awal petugas untuk laporan SAFE v2, kemas kini status, makluman umum dan pautan bukti sementara.
- Tambah carian laporan pada dashboard staf (rujukan, kategori, lokasi dan kata kunci), penapis status serta ringkasan jumlah laporan, kes belum ditutup dan laporan bertanda risiko segera.
- Tambah API server untuk laporan, semakan status, role checks, pengurusan pengguna, audit log dan media peribadi.
- Alih pengurusan pengguna kepada API server, bukan panggilan CRUD terus daripada browser.
- Ganti kawalan PIN frontend lama kepada semakan Firebase custom claims/role yang disahkan.
- Buang konfigurasi Firebase aktif lama sebagai nilai lalai; projek memerlukan konfigurasi environment baharu yang disengajakan.
- Sediakan contoh Firestore/Storage Rules dan dokumentasi setup, migrasi, keselamatan dan roadmap.

## Belum siap / memerlukan persediaan pemilik

- Backend tidak akan menerima laporan sehingga Firebase Admin dan Cloud Storage disediakan.
- Log masuk Google/manual perlu diuji menggunakan Firebase project yang diluluskan dan role claims yang ditetapkan melalui prosedur trusted.
- Firestore dan Storage Rules sebenar perlu disemak, disepadukan dengan rules lain dan diuji; fail `.example` bukan rules yang telah dipasang.
- Turnstile production perlu dikonfigurasikan dan diuji.
- Migrasi data lama daripada `users`, `reports`, SAFE lama dan koleksi berkaitan belum dijalankan.
- SAFE Impact Dashboard sebenar masih belum siap. Pengurusan program yang kini tersedia hanyalah prototaip sesi pelayar; penyimpanan berpusat, kawalan peranan, analitik agregat dan audit belum dilaksanakan. Panduan sokongan mangsa, saksi dan perubahan tingkah laku tersedia sebagai bahan panduan awal, tetapi belum menjadi aliran kes/intervensi berstruktur.
- Pelan retention/pemadaman, SOP tindakan sekolah, eskalasi risiko dan pengesahan staf perlu diluluskan sebelum pelancaran.

## Pemeriksaan yang berjaya

- `node --check server/index.mjs` — lulus.
- TypeScript `transpileModule` syntax check untuk 15 fail `.ts/.tsx` selepas kemas kini dashboard — lulus tanpa ralat sintaks.
- TypeScript transpile/syntax check untuk 15 fail `.ts/.tsx` — lulus tanpa ralat sintaks.
- `package.json` — JSON sah.

## Pemeriksaan yang belum berjaya / belum dibuat

Pemasangan NPM dependencies tamat masa dalam persekitaran kerja, oleh itu `npm run build`, `npm run typecheck` dan ujian hujung-ke-hujung belum disahkan. Ini tidak boleh dianggap sebagai pengesahan production.

## Arahan asas

1. Salin `.env.example` kepada `.env.local` dan isi konfigurasi Firebase Web untuk projek yang diluluskan.
2. Salin `server/.env.example` kepada `server/.env` dan isi Firebase Admin, `SAFE_ADMIN_EMAILS`, `MANUAL_ADMIN_IDS`, `FRONTEND_ORIGINS` serta `TURNSTILE_SECRET_KEY`.
3. Jalankan `npm install`.
4. Jalankan `npm run dev` dan dalam terminal kedua `npm run server`.
5. Selepas dependencies siap: jalankan `npm run typecheck` dan `npm run build`.

Jangan muat naik `.env.local`, `server/.env`, service-account key atau data laporan sebenar ke repositori.
- Pengurusan laporan lama, mod penyelenggaraan dan kemas kini tetapan ciri dipindahkan daripada operasi mutasi terus di browser kepada endpoint API yang dikawal akses.
- API pengurusan pengguna kini mengehadkan operasi akaun kepada pentadbir; kaunselor kekal hanya pada laluan kerja kes yang dibenarkan.

Percubaan `npm run build` pada mesin kerja gagal kerana executable Vite tidak tersedia (`vite: not found`), konsisten dengan dependencies yang belum berjaya dipasang. Build produksi perlu dijalankan selepas `npm install` berjaya dalam persekitaran pembangunan.
