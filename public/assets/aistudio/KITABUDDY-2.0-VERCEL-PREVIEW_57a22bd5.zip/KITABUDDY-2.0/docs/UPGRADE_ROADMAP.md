# Pelan Pembangunan KITABUDDY 2.0

## Arah produk

**KITABUDDY kekal sebagai platform utama.** SAFE bermaksud **School Anti-Bullying Framework for Empowerment** dan dibawa sebagai add-on/kerangka pelengkap dalam KITABUDDY 2.0, bukan sebagai produk berasingan pada reka bentuk sasaran.

## Fasa 1 — Audit source code (sedang berjalan)

- Inventori halaman dan komponen KITABUDDY.
- Inventori fungsi SAFE: borang laporan teks/audio/video, Firestore, Firebase Storage, dashboard dan servis notifikasi/AI.
- Pemetaan autentikasi, konfigurasi, koleksi dan field data.
- Penilaian risiko keselamatan dan penetapan perkara yang mesti dimigrasi atau dinyahaktifkan.

## Fasa 2 — Seni bina dan reka bentuk

- Tetapkan satu frontend utama dengan navigasi KITABUDDY.
- Kekalkan modul pembelajaran sedia ada; sediakan laluan SAFE untuk pelaporan, intervensi, pengurusan program dan analitik.
- Pisahkan browser UI daripada servis sensitif melalui backend API.
- Tentukan peranan pelajar/pelapor anonim, guru penerima laporan, kaunselor, pentadbir sekolah dan pentadbir sistem.
- Sediakan data dictionary dan pelan migrasi sebelum memindahkan data sebenar.

## Fasa 3 — MVP berfungsi

- Landing page KITABUDDY dengan tindakan lapor tanpa log masuk.
- Mod laporan teks/foto/audio/video, semakan status menggunakan rujukan + kod rahsia.
- SAFE add-on landing page.
- API server dengan input validation, rate limit, Turnstile untuk production, media private dan server-verified staff access.
- Reka bentuk awal dashboard; penyambungan dashboard penuh memerlukan Firebase Auth/custom claims yang selamat.

## Fasa 4 — Intervensi dan PPBA

- Laluan sokongan mangsa.
- Laluan perubahan tingkah laku pelaku.
- Panduan saksi dan PRS.
- Modul pendidikan PPBA dan bahan guru/ibu bapa.
- Pelan keselamatan, rekod tindakan dan susulan kaunseling mengikut SOP sekolah.

## Fasa 5 — Ujian, migrasi, pilot dan pelancaran

- Ujian fungsian, keselamatan, kebolehcapaian dan peranti.
- Ujian Rules, server-side roles, signed URL dan tempoh retention.
- Data migration dry-run (tanpa mengubah sumber asal), rekonsiliasi kiraan dan rollback.
- Pilot sekolah, pengumpulan maklum balas dan semakan SOP.
- Pelancaran hanya selepas penerimaan teknikal dan operasi.

## Pagar keputusan

Jangan aktifkan pelaporan awam sehingga: (1) Firebase Admin disambungkan, (2) Turnstile aktif, (3) CORS dihadkan kepada domain betul, (4) Firestore/Storage rules diuji, (5) staff identity/claims disahkan oleh server, (6) aliran respons sekolah dan retention disahkan.
