# Pemetaan Modul Lama ke KITABUDDY 2.0

| Modul/ciri lama | Keputusan sasaran | Catatan |
|---|---|---|
| Landing KITABUDDY, identiti pastel, logo/slogan | Kekalkan dan kemas kini | Tambah CTA laporan anonim dan label SAFE add-on. |
| Cerita Ajaib | Kekalkan | Semak kandungan, pautan aset dan aksesibiliti. |
| Teroka Dunia | Kekalkan | Audit aliran pembelajaran/media. |
| Definisi Buli | Kekalkan | Semak definisi dan rujukan pendidikan. |
| Video Kesedaran | Kekalkan | Semak pautan dan hak penggunaan bahan. |
| Cara Mengelak | Kekalkan | Tambah panduan mendapatkan bantuan yang selamat. |
| Lagu Anti Buli | Kekalkan | Kekalkan pautan selepas pengesahan hak/akses. |
| Permainan | Kekalkan | Semak pautan dan kesesuaian umur. |
| Saya Nak Jadi Baik | Kekalkan | Audit destinasi pautan. |
| Laman Web / Padlet Sharing / Hukuman Membuli / Talian Hayat / SOS SPDB | Kekalkan sebagai pautan/modul mengikut status | Semak semula pautan dan pemilik setiap saluran. |
| Berbual Bersama Budi | Kekalkan, kemudian tingkatkan | AI sebenar perlu melalui backend; jangan expose token pada frontend. |
| Log masuk Google/manual | Migrasi berperingkat | Hentikan penyemakan password dalam Firestore; gunakan Firebase Auth dan role/claims trusted. |
| Dashboard/admin KITABUDDY | Reka semula kawalan akses | PIN hard-coded pada frontend tidak dianggap kawalan keselamatan. |
| SAFE: laporan teks/audio/video | Integrasi sebagai SAFE Reporting | Pindah ke API server dan private Storage. Tambah sokongan foto dan category. |
| SAFE: report list/dashboard | Gabung secara berperingkat | Peta struktur report lama kepada `safe_reports_v2` selepas audit format data. |
| SAFE: notifikasi Telegram | Pindah ke server | Bot token mesti disimpan sebagai server secret; notifikasi tidak boleh menggantikan rekod sistem. |
| SAFE: analisis AI | Pindah ke backend atau kekalkan manual fallback | AI tidak boleh menentukan sendiri tahap kes, menyalahkan individu, atau menjadi satu-satunya saluran respons kecemasan. |
| SAFE: kiosk/maintenance settings | Semak keperluan dan reka semula | PIN dan status kawalan yang mempengaruhi keselamatan perlu dikawal dari backend. |

## Tidak dipindahkan secara automatik

- Token, kredensial, private keys dan rahsia dari source code lama.
- Data laporan/murid sebelum semakan tujuan penggunaan, retention, akses dan kaedah pemindahan.
- Kaedah pengesahan berasaskan medan kata laluan biasa dalam Firestore.

## Prinsip migrasi

Kandungan dan ciri dikekalkan, tetapi bukan semua pelaksanaan teknikal lama perlu disalin. Kod yang mewujudkan risiko keselamatan perlu diganti dengan pelaksanaan yang lebih selamat.
