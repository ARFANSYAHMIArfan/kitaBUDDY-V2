
import { initializeApp } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  query, 
  where, 
  getDocs, 
  addDoc, 
  orderBy, 
  onSnapshot,
  serverTimestamp,
  limit,
  doc,
  updateDoc,
  deleteDoc,
  setDoc,
  increment,
  getDoc
} from 'firebase/firestore';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithCustomToken,
  signOut as fbSignOut,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { ChatMessage } from '../types';

// KITABUDDY 2.0 deliberately does not default to the legacy Firebase project.
// Set the VITE_FIREBASE_* values in .env.local or the deployment environment
// after an approved new Firebase project and migration plan have been prepared.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || 'KITABUDDY_NOT_CONFIGURED',
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'localhost',
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL || undefined,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'kitabuddy-2-0-not-configured',
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || 'kitabuddy-2-0-not-configured.appspot.com',
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '000000000000',
  appId: import.meta.env.VITE_FIREBASE_APP_ID || '1:000000000000:web:0000000000000000000000',
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || undefined,
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Initialize Firebase Authentication
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

export interface GoogleAuthResult {
  id: string;
  name: string;
  role: string;
  email: string;
  photoURL?: string;
  uid: string;
}

/**
 * Log masuk menggunakan Google Sign-In pop-up
 */
export const signInWithGoogle = async (): Promise<GoogleAuthResult> => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    const email = user.email || '';
    const name = user.displayName || email.split('@')[0] || 'Pengguna Google';
    const photoURL = user.photoURL || undefined;
    let role = 'student';

    // Role admin mesti datang daripada custom claim yang disahkan oleh Firebase Admin.
    // Jangan menaikkan role berdasarkan substring "admin" dalam alamat e-mel.
    const apiBase = (import.meta.env.VITE_REPORT_API_URL || '').trim().replace(/\/$/, '');
    if (apiBase) {
      try {
        const idToken = await user.getIdToken();
        const response = await fetch(`${apiBase}/api/auth/sync-google-role`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ idToken }),
        });
        if (response.ok) await user.getIdToken(true);
      } catch {
        // Google sign-in may remain available as a standard student account if the role-sync API is offline.
        // Privileged UI/API access remains fail-closed because the server checks trusted roles.
      }
    }
    const tokenResult = await user.getIdTokenResult(true);
    const claimedRole = String(tokenResult.claims.role || tokenResult.claims.safeRole || '').toLowerCase();
    if (tokenResult.claims.admin === true || ['admin', 'school_admin'].includes(claimedRole)) role = 'admin';
    else if (claimedRole === 'counselor') role = 'counselor';
    else if (claimedRole === 'teacher') role = 'teacher';

    // Simpan profil asas sahaja; role sensitif tidak ditetapkan oleh frontend.
    try {
      await setDoc(doc(db, 'users', user.uid), {
        studentId: email,
        name,
        photoURL: photoURL || '',
        provider: 'google',
        lastLogin: serverTimestamp(),
      }, { merge: true });
    } catch (err) {
      console.warn('Tidak dapat menyelaraskan profil asas pengguna ke Firestore.');
    }

    return { id: email || user.uid, name, role, email, photoURL, uid: user.uid };
  } catch (error: any) {
    console.error('Ralat Log Masuk Google:', error?.code || 'unknown');
    throw error;
  }
};

/**
 * Log keluar pengguna daripada Firebase Auth
 */
export const logoutFirebase = async () => {
  try {
    await fbSignOut(auth);
  } catch (error) {
    console.error('Ralat log keluar Firebase:', error);
  }
};

/**
 * Dengar perubahan status pengesahan Firebase
 */
export const onAuthStatusChanged = (callback: (user: FirebaseUser | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

const adminApiRequest = async (path: string, init: RequestInit = {}) => {
  const apiBase = (import.meta.env.VITE_REPORT_API_URL || '').trim().replace(/\/$/, '');
  if (!apiBase) throw new Error('Backend API belum dikonfigurasikan.');
  const currentUser = auth.currentUser;
  if (!currentUser) throw new Error('Sesi Firebase Authentication diperlukan.');
  const token = await currentUser.getIdToken();
  const headers = new Headers(init.headers || {});
  headers.set('Authorization', `Bearer ${token}`);
  if (init.body && !(init.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const response = await fetch(`${apiBase}${path}`, { ...init, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Permintaan pentadbir gagal.');
  return data;
};

export const loginUser = async (studentId: string, password: string) => {
  const apiBase = (import.meta.env.VITE_REPORT_API_URL || '').trim().replace(/\/$/, '');
  if (!apiBase) {
    throw new Error('Log masuk ID manual belum disambungkan kepada backend yang selamat. Sila gunakan log masuk Google atau minta pentadbir menyediakan API.');
  }
  try {
    const response = await fetch(`${apiBase}/api/auth/manual`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studentId: studentId.trim(), password }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || 'ID atau kata laluan tidak sah.');
    if (!data.customToken) throw new Error('Pelayan pengesahan tidak memulangkan token sesi yang sah.');
    await signInWithCustomToken(auth, data.customToken);
    return { id: data.studentId || studentId.trim(), name: data.name || studentId.trim(), role: data.role || 'student' };
  } catch (error: any) {
    console.error('Ralat log masuk ID manual:', error?.message || 'unknown error');
    throw error;
  }
};

export const subscribeToChat = (userId: string, callback: (messages: ChatMessage[]) => void) => {
  // Create a reference to the specific user's chat collection
  const messagesRef = collection(db, 'chats', userId, 'messages');
  const q = query(messagesRef, orderBy('timestamp', 'asc'), limit(50));

  return onSnapshot(q, (snapshot) => {
    const messages: ChatMessage[] = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as ChatMessage));
    callback(messages);
  });
};

export const saveChatMessage = async (userId: string, message: Omit<ChatMessage, 'id'>) => {
  try {
    const messagesRef = collection(db, 'chats', userId, 'messages');
    await addDoc(messagesRef, {
      ...message,
      timestamp: Date.now() // Ensure numerical timestamp for sorting
    });
  } catch (error) {
    console.error("Error saving message:", error);
  }
};

// --- User Management ---

export const getUsers = async () => {
  try {
    const data = await adminApiRequest('/api/admin/users');
    return Array.isArray(data.users) ? data.users : [];
  } catch (error) {
    console.error('Error fetching users through SAFE API:', error instanceof Error ? error.message : 'unknown');
    return [];
  }
};

export const addUser = async (userData: { studentId: string; name: string; role: string; password?: string }) => {
  try {
    await adminApiRequest('/api/admin/users', {
      method: 'POST',
      body: JSON.stringify({ ...userData, password: userData.password || '' }),
    });
    return true;
  } catch (error) {
    console.error('Error adding user through SAFE API:', error instanceof Error ? error.message : 'unknown');
    return false;
  }
};

export const updateUserRole = async (docId: string, newRole: string) => {
  try {
    await adminApiRequest(`/api/admin/users/${encodeURIComponent(docId)}/role`, {
      method: 'PATCH', body: JSON.stringify({ role: newRole }),
    });
    return true;
  } catch (error) {
    console.error('Error updating user role through SAFE API:', error instanceof Error ? error.message : 'unknown');
    return false;
  }
};

export const deleteUser = async (docId: string) => {
  try {
    await adminApiRequest(`/api/admin/users/${encodeURIComponent(docId)}`, { method: 'DELETE' });
    return true;
  } catch (error) {
    console.error('Error deleting user through SAFE API:', error instanceof Error ? error.message : 'unknown');
    return false;
  }
};

// --- Legacy report management (API protected; no direct browser writes) ---

export const getReports = async () => {
  try {
    const data = await adminApiRequest('/api/admin/legacy-reports');
    return Array.isArray(data.reports) ? data.reports : [];
  } catch (error) {
    console.error('Error fetching reports through API:', error instanceof Error ? error.message : 'unknown');
    return [];
  }
};

export const addReport = async (reportData: { student: string; class: string; issue: string }) => {
  try {
    await adminApiRequest('/api/admin/legacy-reports', { method: 'POST', body: JSON.stringify(reportData) });
    return true;
  } catch (error) {
    console.error('Error adding report through API:', error instanceof Error ? error.message : 'unknown');
    return false;
  }
};

export const updateReport = async (docId: string, data: { status: string }) => {
  try {
    await adminApiRequest(`/api/admin/legacy-reports/${encodeURIComponent(docId)}/status`, {
      method: 'PATCH', body: JSON.stringify(data),
    });
    return true;
  } catch (error) {
    console.error('Error updating report through API:', error instanceof Error ? error.message : 'unknown');
    return false;
  }
};

export const deleteReport = async (docId: string) => {
  try {
    await adminApiRequest(`/api/admin/legacy-reports/${encodeURIComponent(docId)}`, { method: 'DELETE' });
    return true;
  } catch (error) {
    console.error('Error deleting report through API:', error instanceof Error ? error.message : 'unknown');
    return false;
  }
};

// --- Feature Management ---

const publicApiRequest = async (path: string, init: RequestInit = {}) => {
  const apiBase = (import.meta.env.VITE_REPORT_API_URL || '').trim().replace(/\/$/, '');
  if (!apiBase) throw new Error('Backend API belum dikonfigurasikan.');
  const headers = new Headers(init.headers || {});
  if (init.body && !(init.body instanceof FormData) && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const response = await fetch(`${apiBase}${path}`, { ...init, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Permintaan API gagal.');
  return data;
};

export const getFeatures = async () => {
  try {
    const data = await publicApiRequest('/api/features');
    return data.features && typeof data.features === 'object' ? data.features : {};
  } catch (error) {
    console.error('Error getting features from API:', error instanceof Error ? error.message : 'unknown');
    return {};
  }
};

export const updateFeature = async (featureId: string, data: { title: string; status: string; message: string }) => {
  try {
    await adminApiRequest(`/api/admin/features/${encodeURIComponent(featureId)}`, {
      method: 'PATCH', body: JSON.stringify(data),
    });
    return true;
  } catch (error) {
    console.error('Error updating feature through API:', error instanceof Error ? error.message : 'unknown');
    return false;
  }
};

// --- Analytics ---

export const incrementFeatureUsage = async (featureId: string) => {
  try {
    await publicApiRequest(`/api/analytics/features/${encodeURIComponent(featureId)}/usage`, { method: 'POST' });
  } catch (error) {
    console.warn('Statistik penggunaan tidak direkodkan:', error instanceof Error ? error.message : 'unknown');
  }
};

export const getFeatureUsage = async () => {
  try {
    const data = await adminApiRequest('/api/admin/analytics/features');
    return data.usage && typeof data.usage === 'object' ? data.usage : {};
  } catch (error) {
    console.error('Error fetching analytics through API:', error instanceof Error ? error.message : 'unknown');
    return {};
  }
};

// --- System Settings ---

export const getSettings = async () => {
  try {
    return await publicApiRequest('/api/settings/public');
  } catch (error) {
    console.warn('Tetapan sistem tidak dapat dimuatkan:', error instanceof Error ? error.message : 'unknown');
    return { maintenanceMode: false };
  }
};

export const toggleMaintenanceMode = async (enabled: boolean) => {
  try {
    const data = await adminApiRequest('/api/admin/settings/maintenance', {
      method: 'PATCH', body: JSON.stringify({ enabled }),
    });
    return data.maintenanceMode === enabled;
  } catch (error) {
    console.error('Tetapan penyelenggaraan tidak dapat disimpan:', error instanceof Error ? error.message : 'unknown');
    return false;
  }
};
