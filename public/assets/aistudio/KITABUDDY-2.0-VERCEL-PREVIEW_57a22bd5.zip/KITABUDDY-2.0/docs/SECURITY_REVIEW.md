# Semakan Keselamatan Awal — KITABUDDY 2.0 + SAFE

Semakan ini berdasarkan pemeriksaan source code ZIP yang diberikan. Ia bukan penetration test dan tidak mengesahkan keadaan sebenar projek Firebase yang sedang aktif.

## Risiko yang jelas dalam source code

1. **Rahsia/konfigurasi perkhidmatan dalam frontend SAFE lama.** Beberapa penyepaduan menggunakan nilai yang ditulis terus dalam source code. Token penyedia AI/Telegram yang aktif perlu dianggap terdedah, dibatalkan/dirotasi dan dipindahkan ke server environment secrets. Firebase web config bukan private key dengan sendirinya, tetapi API key perlu dihadkan mengikut projek/API/domain.
2. **Kata laluan manual dicari terus dalam Firestore.** KITABUDDY lama membandingkan `studentId` dan `password` menggunakan query Firestore, dan penambahan pengguna mempunyai kata laluan lalai. Ini bukan aliran pengesahan yang sesuai untuk production. Gunakan Firebase Authentication atau identity provider yang dipercayai serta migrasi akaun.
3. **PIN kawalan dalam JavaScript frontend.** PIN admin/backend/maintenance berada dalam code client, jadi ia boleh dilihat atau dilewati. Pindahkan kawalan akses ke backend, Firebase custom claims dan Rules.
4. **Pemberian role di client perlu disahkan semula.** Pemeriksaan alamat e-mel atau substring `admin` di client bukan sumber autoritatif. Role sensitif mesti ditentukan oleh trusted server/custom claims dan dikuatkuasakan oleh API/Rules.
5. **Logik media SAFE lama.** Media dimuat naik dan laporan disimpan melalui client services. Akses sebenar bergantung pada Storage/Firestore Rules yang tidak disertakan dalam ZIP. Rules mesti diaudit sebelum sebarang data sensitif dianggap dilindungi.
6. **Kiosk/session PIN.** Semak mekanisme sesi, expirations, brute-force protection, logging dan amalan lockout sebelum reuse.

## Kawalan yang ditambah dalam MVP baharu

- API server berasingan; tiada token AI/Telegram lama disalin ke frontend.
- Laporan baharu disimpan ke `safe_reports_v2`, bukan terus ke koleksi lama.
- Bukti disimpan menggunakan private object path; URL akses dijana sementara dan dicatat dalam audit log.
- Semakan status memerlukan kedua-dua reference dan kod rahsia. Kod rahsia disimpan sebagai hash.
- Validasi jenis dan saiz media, rate limiting, CORS allowlist, Helmet dan Turnstile wajib dalam production.
- Contoh Firestore/Storage Rules menolak akses browser terus kepada koleksi/laluan SAFE v2.
- Dashboard API memerlukan Firebase ID token yang disahkan dan custom role claim trusted atau e-mel allowlist.

## Perkara yang belum disahkan

- Firestore/Storage Rules aktif dan deployed.
- Firebase Authentication providers, authorized domains dan custom claims.
- Sama ada token dalam source code masih aktif atau sudah dibatalkan.
- Konfigurasi Cloud Storage bucket, retention, backups dan access logs.
- Status pematuhan, proses respons murid, jadual on-call dan SOP sekolah.

## Pagar pelancaran

Jangan lancarkan pelaporan awam sebelum audit Rules, konfigurasi anti-bot production, identity staff yang sah, prosedur respons segera, retention/pemadaman, sandaran dan ujian keselamatan dilengkapkan.

## Pembetulan akses yang turut dimasukkan dalam KITABUDDY 2.0

- Pengurusan akaun pengguna kini di API server; counselor tidak diberi kuasa untuk menambah, mengubah role atau memadam akaun hanya kerana mereka boleh mengurus kes.
- Pengurusan laporan lama, kemas kini ciri dan mod penyelenggaraan juga dialihkan ke API yang memerlukan staf disahkan.
- Statistik dashboard dibaca melalui API pentadbir; kiraan penggunaan dihantar ke API dengan rate limit.
- Firebase client config projek lama tidak lagi menjadi fallback automatik. Projek perlu diikat dengan konfigurasi environment Firebase yang diluluskan sebelum penggunaan sebenar.
